**Current State**
- Uses a simple file-based store: users.db (plaintext) via FileUserRepository, wrapped by UserStore.
- Gmail-only usernames enforced in auth dialogs.
- Two-file demo available; no DB server required.

**Your Screenshot**
- Shows phpMyAdmin for MariaDB on localhost. If we connect from Java, we use MySQL Connector/J (works with MariaDB) over JDBC.

**Option A — Keep Simple (Recommended for presentation)**
- No changes; continue with users.db flat file.
- Fast to demo; zero external setup.

**Option B — Switch to MariaDB (JDBC)**
1. Add MySQLUserRepository implementing UserRepository with JDBC CRUD and auto-create table users(username, password, best).
2. Introduce a small RepositoryFactory that selects FileUserRepository by default, or MySQLUserRepository when db.properties is present.
3. Add db.properties (url, user, password, table) and document sample values (e.g., jdbc:mysql://localhost:3306/dino_game).
4. Update DISCREPTION with connection steps and classpath instruction for Connector/J.
5. Test: create database dino_game in phpMyAdmin, compile with Connector/J JAR, run signup/login and verify records.

**Notes**
- We will keep plaintext passwords per your request (presentation-only). We can restore hashing later if needed.

Please confirm Option A or Option B, and I will implement accordingly.