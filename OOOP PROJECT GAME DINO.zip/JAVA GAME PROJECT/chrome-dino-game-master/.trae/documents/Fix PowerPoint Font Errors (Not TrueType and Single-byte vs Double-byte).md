**What’s Happening**
- Your PPT uses a double-byte font (East Asian font) in some text. Replacing it with a single-byte font triggers: “Select a double-byte font”.
- Another error showed “Muli – Not TrueType”, meaning the font can’t be embedded.

**Fast Fix Steps**
1. Identify fonts
- Home → Replace → Replace Fonts…
- Note any listed non‑Latin/East Asian fonts (e.g., MS Mincho, MS Gothic, Meiryo, SimSun, Microsoft YaHei, Malgun Gothic, Yu Gothic).

2. Replace double-byte with double-byte
- In Replace Fonts, for each double‑byte font, choose a double‑byte replacement:
  - Recommended on Windows: Microsoft YaHei UI, Yu Gothic UI, Meiryo, Malgun Gothic
- Run Replace; the “single‑byte vs double‑byte” warning will not appear.

3. Replace non‑TrueType fonts
- For Muli, replace with a TTF: Mulish, Segoe UI, Calibri, Arial.

4. Embed fonts for sharing
- File → Options → Save → tick “Embed fonts in the file” → choose “Embed only the characters used”. Save.

5. Clean up Slide Master
- View → Slide Master → select top master → fix Title/Body fonts there (use the same replacements). Close Master View.
- Design → Fonts → choose Office Theme (Segoe UI/Calibri) or create Custom Fonts with your chosen replacements.

6. Verify quickly
- Home → Replace → Replace Fonts… again; it should only list your chosen fonts.
- Save without warnings.

**If any text still warns**
- Select that textbox → change font manually to the double‑byte replacement.
- Re-run Replace Fonts.

**Backup Option**
- Export → Create PDF if you must share immediately without font issues.

I will proceed to apply these replacements and set embed‑fonts in your PPT if you confirm the target replacements (e.g., Microsoft YaHei UI for CJK + Segoe UI for Latin).