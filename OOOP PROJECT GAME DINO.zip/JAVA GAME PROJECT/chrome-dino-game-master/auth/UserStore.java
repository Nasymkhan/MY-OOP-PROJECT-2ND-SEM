package auth;

public class UserStore {
  private final UserRepository repo;
  public UserStore() {
    java.io.File props = new java.io.File("db.properties");
    if(props.exists()) {
      repo = new MySQLUserRepository();
    } else  {
      repo = new FileUserRepository();
    }
  }

  public boolean userExists(String u) {
    return repo.userExists(u);
  }

  public boolean create(String u, String p) {
    return repo.create(new User(u, p, 0, "", ""));
  }
  public boolean create(String u, String p, String name, String mobile) {
    return repo.create(new User(u, p, 0, name, mobile));
  }

  public boolean verify(String u, String p) {
    return repo.verify(u, p);
  }

  public int best(String u) {
    return repo.best(u);
  }

  public void updateBest(String u, int score) {
    repo.updateBest(u, score);
  }
  public java.util.List<User> list() { return repo.list(); }
  public void delete(String u) { repo.delete(u); }
}
