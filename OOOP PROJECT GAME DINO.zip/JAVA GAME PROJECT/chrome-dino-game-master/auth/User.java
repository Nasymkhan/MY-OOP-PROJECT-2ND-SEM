package auth;

public class User {
  private final String username;
  private final String password;
  private final int best;
  private final String name;
  private final String mobile;

  public User(String username, String password, int best, String name, String mobile) {
    this.username = username;
    this.password = password;
    this.best = best;
    this.name = name;
    this.mobile = mobile;
  }

  public String getUsername() { return username; }
  public String getPassword() { return password; }
  public int getBest() { return best; }
  public String getName() { return name; }
  public String getMobile() { return mobile; }
}
