package auth;

public interface UserRepository {
  boolean userExists(String u);
  boolean create(User user);
  boolean verify(String u, String p);
  int best(String u);
  void updateBest(String u, int score);
  java.util.List<User> list();
  void delete(String u);
}
