package auth;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.Graphics;
import java.io.File;
import java.awt.Font;
import java.awt.Component;

public class AuthDialog extends JDialog {
  private JTextField loginEmail = new JTextField();
  private JPasswordField loginPass = new JPasswordField();
  private JTextField signName = new JTextField();
  private JTextField signEmail = new JTextField();
  private JTextField signMobile = new JTextField();
  private JPasswordField signPass = new JPasswordField();
  private String selectedUser;
  public AuthDialog(JFrame parent) {
    super(parent, "Login / Sign up", true);
    JPanel loginForm = new JPanel(new GridLayout(2,2,12,12));
    loginForm.add(new JLabel("Email"));
    loginForm.add(loginEmail);
    loginForm.add(new JLabel("Password"));
    loginForm.add(loginPass);
    JPanel signForm = new JPanel(new GridLayout(4,2,12,12));
    signForm.add(new JLabel("Name"));
    signForm.add(signName);
    signForm.add(new JLabel("Email"));
    signForm.add(signEmail);
    signForm.add(new JLabel("Mobile"));
    signForm.add(signMobile);
    signForm.add(new JLabel("Password"));
    signForm.add(signPass);
    JTabbedPane tabs = new JTabbedPane();
    tabs.addTab("Login", loginForm);
    tabs.addTab("Create Account", signForm);
    JButton login = new JButton("Login");
    JButton signup = new JButton("Create Account");
    JPanel actions = new JPanel();
    actions.add(login);
    actions.add(signup);
    JButton admin = new JButton("Admin");
    actions.add(admin);
    Image bgImage = null;
    try {
      String base = "C:\\Users\\nk334\\OneDrive\\Desktop\\Create a desktop wal";
      String[] exts = new String[]{"", ".png", ".jpg", ".jpeg"};
      for(String ext: exts) {
        File f = new File(base+ext);
        if(f.exists()) { bgImage = ImageIO.read(f); break; }
      }
    } catch(Exception ignored) {}
    final Image bg = bgImage;
    JPanel bgPanel = new JPanel(new BorderLayout(8,8)) {
      protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if(bg != null) g.drawImage(bg, 0, 0, getWidth(), getHeight(), null);
      }
    };
    setContentPane(bgPanel);
    loginForm.setOpaque(false);
    signForm.setOpaque(false);
    actions.setOpaque(false);
    bgPanel.add(tabs, BorderLayout.CENTER);
    bgPanel.add(actions, BorderLayout.SOUTH);
    setSize(420,260);
    setLocationRelativeTo(parent);
    UserStore store = new UserStore();
    login.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        String u = loginEmail.getText().trim();
        String p = new String(loginPass.getPassword());
        if(u.equalsIgnoreCase("admin") && p.equals("admin")) {
          dispose();
          new AdminPanel();
          return;
        }
        if(store.verify(u,p)){
          selectedUser = u;
          dispose();
        } else {
          JOptionPane.showMessageDialog(AuthDialog.this, "Incorrect. Please sign up first.");
        }
      }
    });
    signup.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        String n = signName.getText().trim();
        String u = signEmail.getText().trim();
        String m = signMobile.getText().trim();
        String p = new String(signPass.getPassword());
        String ul = u.toLowerCase();
        if(n.isEmpty() || u.isEmpty() || p.isEmpty()) {
          JOptionPane.showMessageDialog(AuthDialog.this, "Name, email, and password are required");
          return;
        }
        if(!ul.endsWith("@gmail.com")) {
          JOptionPane.showMessageDialog(AuthDialog.this, "Please use a Gmail address (must end with @gmail.com)");
          return;
        }
        if(!(m.matches("^03\\d{9}$") || m.matches("^\\+923\\d{10}$"))) {
          JOptionPane.showMessageDialog(AuthDialog.this, "Mobile must be 03xxxxxxxxx or +923xxxxxxxxxx");
          return;
        }
        if(store.create(u,p,n,m)){
          selectedUser = u;
          dispose();
        } else {
          JOptionPane.showMessageDialog(AuthDialog.this, "User already exists");
        }
      }
    });
    getRootPane().setDefaultButton(login);
    admin.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        dispose();
        new AdminPanel();
      }
    });
  }
  public static String show(JFrame parent){
    AuthDialog d = new AuthDialog(parent);
    d.setVisible(true);
    return d.selectedUser;
  }
}
