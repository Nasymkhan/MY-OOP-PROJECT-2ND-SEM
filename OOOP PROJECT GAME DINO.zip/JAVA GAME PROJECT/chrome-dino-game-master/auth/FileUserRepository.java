package auth;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedHashMap;
import java.util.Map;

public class FileUserRepository implements UserRepository {
  private final File file = new File("users.db");
  private Map<String, Record> data = new LinkedHashMap<>();
  private static class Record {
    String password;
    int best;
    String name;
    String mobile;
  }

  private void load() {
    data.clear();
    if(!file.exists()) return;
    try(BufferedReader br = new BufferedReader(new FileReader(file))) {
      String line;
      while((line = br.readLine()) != null) {
        String[] p = line.split(":", 5);
        if(p.length >= 2) {
          Record r = new Record();
          r.password = p[1];
          r.best = p.length == 3 ? Integer.parseInt(p[2]) : 0;
          r.name = p.length >= 4 ? p[3] : "";
          r.mobile = p.length >= 5 ? p[4] : "";
          data.put(p[0], r);
        }
      }
    } catch(Exception e) {}
  }

  private void persist() {
    try(BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
      for(Map.Entry<String, Record> e : data.entrySet()) {
        bw.write(e.getKey()+":"+e.getValue().password+":"+e.getValue().best+":"+e.getValue().name+":"+e.getValue().mobile);
        bw.newLine();
      }
    } catch(Exception e) {}
  }

  public boolean userExists(String u) {
    load();
    return data.containsKey(u);
  }

  public boolean create(User user) {
    load();
    if(data.containsKey(user.getUsername())) return false;
    Record r = new Record();
    r.password = user.getPassword();
    r.best = user.getBest();
    r.name = user.getName();
    r.mobile = user.getMobile();
    data.put(user.getUsername(), r);
    persist();
    return true;
  }

  public boolean verify(String u, String p) {
    load();
    Record r = data.get(u);
    if(r == null) return false;
    return r.password.equals(p);
  }

  public int best(String u) {
    load();
    Record r = data.get(u);
    return r == null ? 0 : r.best;
  }

  public void updateBest(String u, int score) {
    load();
    Record r = data.get(u);
    if(r == null) return;
    if(score > r.best) {
      r.best = score;
      persist();
    }
  }

  public java.util.List<User> list() {
    load();
    java.util.ArrayList<User> out = new java.util.ArrayList<>();
    for(Map.Entry<String, Record> e : data.entrySet()) {
      Record r = e.getValue();
      out.add(new User(e.getKey(), r.password, r.best, r.name, r.mobile));
    }
    return out;
  }

  public void delete(String u) {
    load();
    data.remove(u);
    persist();
  }
}
