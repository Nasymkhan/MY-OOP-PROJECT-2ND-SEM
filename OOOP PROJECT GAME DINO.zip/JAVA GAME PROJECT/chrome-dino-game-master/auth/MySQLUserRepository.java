package auth;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class MySQLUserRepository implements UserRepository {
  private Connection conn;
  private String table = "users";

  public MySQLUserRepository() {
    try {
      File propsFile = new File("db.properties");
      Properties props = new Properties();
      props.load(new FileInputStream(propsFile));
      String url = props.getProperty("url");
      String user = props.getProperty("user");
      String password = props.getProperty("password");
      String t = props.getProperty("table");
      if(t != null && !t.isEmpty()) table = t;
      Class.forName("com.mysql.cj.jdbc.Driver");
      conn = DriverManager.getConnection(url, user, password);
      try(Statement st = conn.createStatement()){
        st.executeUpdate("CREATE TABLE IF NOT EXISTS "+table+" ("
          + "username VARCHAR(191) PRIMARY KEY,"
          + "password VARCHAR(191) NOT NULL,"
          + "best INT DEFAULT 0,"
          + "name VARCHAR(191),"
          + "mobile VARCHAR(32))");
      }
      try(Statement st = conn.createStatement()){
        try { st.executeUpdate("ALTER TABLE "+table+" ADD COLUMN name VARCHAR(191)"); } catch(Exception ignore) {}
        try { st.executeUpdate("ALTER TABLE "+table+" ADD COLUMN mobile VARCHAR(32)"); } catch(Exception ignore) {}
      }
    } catch(Exception e) {
      throw new RuntimeException(e);
    }
  }

  public boolean userExists(String u) {
    try(PreparedStatement ps = conn.prepareStatement("SELECT 1 FROM "+table+" WHERE username=?")) {
      ps.setString(1, u);
      try(ResultSet rs = ps.executeQuery()){
        return rs.next();
      }
    } catch(Exception e) { return false; }
  }

  public boolean create(User user) {
    try {
      try(PreparedStatement check = conn.prepareStatement("SELECT 1 FROM "+table+" WHERE username=?")){
        check.setString(1, user.getUsername());
        try(ResultSet rs = check.executeQuery()){
          if(rs.next()) return false;
        }
      }
      try(PreparedStatement ins = conn.prepareStatement("INSERT INTO "+table+"(username,password,best,name,mobile) VALUES(?,?,?,?,?)")){
        ins.setString(1, user.getUsername());
        ins.setString(2, user.getPassword());
        ins.setInt(3, user.getBest());
        ins.setString(4, user.getName());
        ins.setString(5, user.getMobile());
        ins.executeUpdate();
        return true;
      }
    } catch(Exception e) { return false; }
  }

  public boolean verify(String u, String p) {
    try(PreparedStatement ps = conn.prepareStatement("SELECT password FROM "+table+" WHERE username=?")){
      ps.setString(1, u);
      try(ResultSet rs = ps.executeQuery()){
        if(!rs.next()) return false;
        return p.equals(rs.getString(1));
      }
    } catch(Exception e) { return false; }
  }

  public int best(String u) {
    try(PreparedStatement ps = conn.prepareStatement("SELECT best FROM "+table+" WHERE username=?")){
      ps.setString(1, u);
      try(ResultSet rs = ps.executeQuery()){
        if(!rs.next()) return 0;
        return rs.getInt(1);
      }
    } catch(Exception e) { return 0; }
  }

  public void updateBest(String u, int score) {
    try {
      int current = 0;
      try(PreparedStatement ps = conn.prepareStatement("SELECT best FROM "+table+" WHERE username=?")){
        ps.setString(1, u);
        try(ResultSet rs = ps.executeQuery()){
          if(rs.next()) current = rs.getInt(1);
        }
      }
      if(score > current) {
        try(PreparedStatement up = conn.prepareStatement("UPDATE "+table+" SET best=? WHERE username=?")){
          up.setInt(1, score);
          up.setString(2, u);
          up.executeUpdate();
        }
      }
    } catch(Exception e) {}
  }

  public java.util.List<User> list() {
    java.util.ArrayList<User> out = new java.util.ArrayList<>();
    try(Statement st = conn.createStatement()){
      try(ResultSet rs = st.executeQuery("SELECT username,password,best,name,mobile FROM "+table+" ORDER BY username")) {
        while(rs.next()) {
          out.add(new User(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5)));
        }
      }
    } catch(Exception e) {}
    return out;
  }

  public void delete(String u) {
    try(PreparedStatement ps = conn.prepareStatement("DELETE FROM "+table+" WHERE username=?")){
      ps.setString(1, u);
      ps.executeUpdate();
    } catch(Exception e) {}
  }
}
