package auth;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class AdminPanel extends JFrame {
  private final UserStore store = new UserStore();
  private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Username","Name","Mobile","Best"},0){
    public boolean isCellEditable(int r,int c){return false;}
  };
  private final JTable table = new JTable(model);
  public AdminPanel() {
    super("Admin Panel");
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    setLayout(new BorderLayout(8,8));
    add(new JScrollPane(table), BorderLayout.CENTER);
    JPanel actions = new JPanel();
    JButton refresh = new JButton("Refresh");
    JButton create = new JButton("Create User");
    JButton delete = new JButton("Delete Selected");
    JButton close = new JButton("Close");
    actions.add(refresh); actions.add(create); actions.add(delete); actions.add(close);
    add(actions, BorderLayout.SOUTH);
    setSize(600,400);
    setLocationRelativeTo(null);
    refresh.addActionListener(new ActionListener(){ public void actionPerformed(ActionEvent e){ load(); }});
    create.addActionListener(new ActionListener(){ public void actionPerformed(ActionEvent e){ createUser(); }});
    delete.addActionListener(new ActionListener(){ public void actionPerformed(ActionEvent e){ deleteSelected(); }});
    close.addActionListener(new ActionListener(){ public void actionPerformed(ActionEvent e){ dispose(); }});
    load();
    setVisible(true);
  }
  private void load() {
    try {
      model.setRowCount(0);
      java.util.List<User> list = store.list();
      for(User u: list) {
        model.addRow(new Object[]{u.getUsername(), u.getName(), u.getMobile(), u.getBest()});
      }
    } catch(Exception ex) {
      JOptionPane.showMessageDialog(this, "Failed to load users");
    }
  }
  private void createUser() {
    JTextField name = new JTextField();
    JTextField email = new JTextField();
    JTextField mobile = new JTextField();
    JPasswordField pass = new JPasswordField();
    JPanel p = new JPanel(new GridLayout(4,2,8,8));
    p.add(new JLabel("Name")); p.add(name);
    p.add(new JLabel("Email")); p.add(email);
    p.add(new JLabel("Mobile")); p.add(mobile);
    p.add(new JLabel("Password")); p.add(pass);
    int res = JOptionPane.showConfirmDialog(this, p, "Create User", JOptionPane.OK_CANCEL_OPTION);
    if(res != JOptionPane.OK_OPTION) return;
    String n = name.getText().trim();
    String e = email.getText().trim();
    String m = mobile.getText().trim();
    String pw = new String(pass.getPassword());
    if(n.isEmpty() || e.isEmpty() || pw.isEmpty()) { JOptionPane.showMessageDialog(this,"All fields required"); return; }
    String el = e.toLowerCase();
    if(!el.endsWith("@gmail.com")) { JOptionPane.showMessageDialog(this,"Email must end with @gmail.com"); return; }
    if(!(m.matches("^03\\d{9}$") || m.matches("^\\+923\\d{10}$"))) { JOptionPane.showMessageDialog(this,"Mobile must be 03xxxxxxxxx or +923xxxxxxxxxx"); return; }
    try {
      if(store.userExists(e)) { JOptionPane.showMessageDialog(this,"User exists"); return; }
      if(store.create(e, pw, n, m)) { load(); JOptionPane.showMessageDialog(this,"User created"); }
      else { JOptionPane.showMessageDialog(this,"Create failed"); }
    } catch(Exception ex) { JOptionPane.showMessageDialog(this,"Create failed"); }
  }
  private void deleteSelected() {
    int row = table.getSelectedRow();
    if(row < 0) { JOptionPane.showMessageDialog(this,"Select a row"); return; }
    String username = (String) model.getValueAt(row, 0);
    try {
      store.delete(username);
      load();
      JOptionPane.showMessageDialog(this,"Deleted");
    } catch(Exception ex) {
      JOptionPane.showMessageDialog(this,"Delete failed");
    }
  }
}
