import java.io.*;
import javax.imageio.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import components.Ground;
import components.Dino;
import components.Obstacles;
import auth.UserStore;

class GamePanel extends JPanel implements KeyListener, Runnable {
  public static int WIDTH;
  public static int HEIGHT;
  private Thread animator;
  
  private boolean running = false;
  private boolean gameOver = false;
  private StringBuilder inputBuffer = new StringBuilder();
  
  Ground ground;
  Dino dino;
  Obstacles obstacles;

  private int score;
  
  public GamePanel() {
    WIDTH = UserInterface.WIDTH;
    HEIGHT = UserInterface.HEIGHT;
    
    ground = new Ground(HEIGHT);
    dino = new Dino();
    obstacles = new Obstacles((int)(WIDTH * 1.5));

    score = 0;
    
    setSize(WIDTH, HEIGHT);
    setVisible(true);
  }
  
  public void paint(Graphics g) {
    super.paint(g);
    g.setColor(new Color(135, 206, 235));
    g.fillRect(0, 0, getWidth(), getHeight());
    g.setColor(new Color(214, 182, 127));
    g.fillRect(0, Ground.GROUND_Y, getWidth(), getHeight() - Ground.GROUND_Y);
    g.setFont(new Font("Courier New", Font.BOLD, 25));
    g.drawString(Integer.toString(score), getWidth()/2 - 5, 100);
    ground.create(g);
    dino.create(g);
    obstacles.create(g);
  }
  
  public void run() {
    running = true;

    while(running) {
      updateGame();
      repaint();      
      try {
        Thread.sleep(50);
      } catch(InterruptedException e) {
        e.printStackTrace();
      }
    }
  }
  
  public void updateGame() {
    score += 1;

    ground.update();
    obstacles.update();

    if(obstacles.hasCollided()) {
      dino.die();
      repaint();
      running = false;
      gameOver = true;
      new UserStore().updateBest(UserInterface.CURRENT_USER, score);
    }
  }

  public void reset() {
    score = 0;
    obstacles.resume();
    gameOver = false;
  }
  
  public void keyTyped(KeyEvent e) {
    char c = e.getKeyChar();
    if(c == ' ') {    
      if(gameOver) reset();
      if (animator == null || !running) {
        animator = new Thread(this);
        animator.start();     
        dino.startRunning();   
      } else {
        dino.jump();
      }
    } else {
      inputBuffer.append(Character.toLowerCase(c));
      if(inputBuffer.length() > 8) inputBuffer.delete(0, inputBuffer.length() - 8);
      if(inputBuffer.toString().endsWith("hack")) {
        obstacles.enableCheat();
      }
      if(inputBuffer.toString().endsWith("off")) {
        obstacles.disableCheat();
        new auth.UserStore().updateBest(UserInterface.CURRENT_USER, score);
      }
    }
  }
  
  public void keyPressed(KeyEvent e) {
  }
  
  public void keyReleased(KeyEvent e) {
  }
}
