package components;

import utility.Resource; // image resource loader

import java.awt.Graphics; // drawing API
import java.awt.image.BufferedImage; // ground texture frame
import java.io.File; // reserved
import java.util.*; // ArrayList, Iterator

import javax.imageio.ImageIO; // image I/O

public class Ground {
  
  private class GroundImage {
    // One segment of ground texture and its x-position
    BufferedImage image;
    int x;
  }
  
  // Y-position where ground is drawn
  public static int GROUND_Y;
  
  private BufferedImage image;
  
  private ArrayList<GroundImage> groundImageSet;
  
  public Ground(int panelHeight) {
    // Place ground at 75% of panel height
    GROUND_Y = (int)(panelHeight - 0.25 * panelHeight);
    
    try{
      // Load the ground texture
      image = new Resource().getResourceImage("../images/Ground.png");
    } catch(Exception e) {e.printStackTrace();}
    
    groundImageSet = new ArrayList<GroundImage>();
    
    // Initialize three segments to scroll seamlessly
    for(int i=0; i<3; i++) {
      GroundImage obj = new GroundImage();
      obj.image = image;
      obj.x = 0;
      groundImageSet.add(obj);
    }
  }
  
  public void update() {
    // Move first segment left and chain-follow the rest
    Iterator<GroundImage> looper = groundImageSet.iterator();
    GroundImage first = looper.next();
    
    first.x -= 10;
    
    int previousX = first.x;
    while(looper.hasNext()) {
      GroundImage next = looper.next();
      next.x = previousX + image.getWidth();
      previousX = next.x;
    }
    
    // Recycle first segment to the end when it goes off-screen
    if(first.x < -image.getWidth()) {
      groundImageSet.remove(first);
      first.x = previousX + image.getWidth();
      groundImageSet.add(first);
    }
    
  }
  
  public void create(Graphics g) {
		// Draw all ground segments at the ground Y-level
		for(GroundImage img : groundImageSet) {
			g.drawImage(img.image, (int) img.x, GROUND_Y, null);
		}
	}
}
