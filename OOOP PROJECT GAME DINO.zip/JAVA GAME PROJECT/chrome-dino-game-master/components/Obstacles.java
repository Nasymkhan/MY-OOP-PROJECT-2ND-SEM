package components;

import java.awt.Color; // drawing colors for plant block
import java.awt.Graphics; // render API
import java.awt.Rectangle; // collision rectangles
import java.awt.image.BufferedImage; // sprite images
import java.util.ArrayList; // lists of images/obstacles
import java.util.Iterator; // iterator for update loop
import java.util.Random; // randomness for variations

import utility.Resource; // resource loader for cactus images

public class Obstacles {
  private class Obstacle {
    // Sprite image (null if small plant)
    BufferedImage image;
    // Position
    int x;
    int y;
    // Flag for small plant placeholder instead of cactus sprite
    boolean smallPlant;
    // Rare collision flag for small plant
    boolean collides;

    Rectangle getObstacle() {
      Rectangle obstacle = new Rectangle();
      obstacle.x = x;
      obstacle.y = y;
      if(smallPlant) {
        obstacle.width = 16;
        obstacle.height = 12;
      } else {
        obstacle.width = image.getWidth();
        obstacle.height = image.getHeight();
      }

      return obstacle;
    }
  }
  
  // Layout and movement parameters
  private int firstX;
  private int obstacleInterval;
  private int movementSpeed;
  // Cheat disables collision and increases speed
  private boolean cheat;
  private Random random;
  
  private ArrayList<BufferedImage> imageList;
  private ArrayList<Obstacle> obList;

  private Obstacle blockedAt;
  
  public Obstacles(int firstPos) {
    obList = new ArrayList<Obstacle>();
    imageList = new ArrayList<BufferedImage>();
    random = new Random();
    
    firstX = firstPos;
    obstacleInterval = 300;
    movementSpeed = 8;
    
    // Load cactus sprites
    imageList.add(new Resource().getResourceImage("../images/Cactus-1.png"));
    imageList.add(new Resource().getResourceImage("../images/Cactus-2.png"));
    imageList.add(new Resource().getResourceImage("../images/Cactus-2.png"));
    imageList.add(new Resource().getResourceImage("../images/Cactus-1.png"));
    // imageList.add(new Resource().getResourceImage("../images/Cactus-3.png"));
    // imageList.add(new Resource().getResourceImage("../images/Cactus-4.png"));
    imageList.add(new Resource().getResourceImage("../images/Cactus-5.png"));
    
    int x = firstX;
    
    for(BufferedImage bi : imageList) {
      Obstacle ob = new Obstacle();
      ob.image = bi;
      ob.x = x;
      ob.y = Ground.GROUND_Y - bi.getHeight() + 5;
      ob.smallPlant = false;
      ob.collides = true;
      x += obstacleInterval;
      obList.add(ob);
    }
    // Append an initial small plant with rare collision
    Obstacle plant = new Obstacle();
    plant.smallPlant = true;
    plant.collides = random.nextDouble() < 0.2;
    plant.x = x;
    plant.y = Ground.GROUND_Y - 12 + 5;
    obList.add(plant);
  }
  
  public void update() {
    // Move all obstacles left and recycle first when off-screen
    Iterator<Obstacle> looper = obList.iterator();
    
    Obstacle firstOb = looper.next();
    firstOb.x -= movementSpeed;
    
    while(looper.hasNext()) {
      Obstacle ob = looper.next();
      ob.x -= movementSpeed;
    }
    
    Obstacle lastOb = obList.get(obList.size() - 1);
    
    if(firstOb.x < -firstOb.image.getWidth()) {
      obList.remove(firstOb);
      firstOb.x = obList.get(obList.size() - 1).x + obstacleInterval;
      // Randomize next entity: small plant (rare collision) or cactus sprite
      if(random.nextDouble() < 0.3) {
        firstOb.smallPlant = true;
        firstOb.image = null;
        firstOb.y = Ground.GROUND_Y - 12 + 5;
        firstOb.collides = random.nextDouble() < 0.2;
      } else {
        BufferedImage bi = imageList.get(random.nextInt(imageList.size()));
        firstOb.smallPlant = false;
        firstOb.image = bi;
        firstOb.y = Ground.GROUND_Y - bi.getHeight() + 5;
        firstOb.collides = true;
      }
      obList.add(firstOb);
    }
  }
  
  public void create(Graphics g) {
    // Draw each obstacle (sprite or small plant block)
    for(Obstacle ob : obList) {
      g.setColor(Color.black);
      if(ob.smallPlant) {
        g.setColor(new Color(34, 139, 34));
        g.fillRect(ob.x, ob.y, 16, 12);
      } else {
        g.drawImage(ob.image, ob.x, ob.y, null);
      }
    }
  }
  
  public boolean hasCollided() {
    // With cheat, collisions are disabled
    if(cheat) return false;
    for(Obstacle ob : obList) {
      if(Dino.getDino().intersects(ob.getObstacle())) {
        // Only count small plant collisions if flagged
        if(!ob.smallPlant || ob.collides) {
          blockedAt = ob;
          return true;
        }
      }
    }
    return false;
  }

  public void resume() {
    // this.obList = null;
    int x = firstX/2;   
    obList = new ArrayList<Obstacle>();
    
    for(BufferedImage bi : imageList) {
      
      Obstacle ob = new Obstacle();
      
      ob.image = bi;
      ob.x = x;
      ob.y = Ground.GROUND_Y - bi.getHeight() + 5;
      ob.smallPlant = false;
      ob.collides = true;
      x += obstacleInterval;
      
      obList.add(ob);
    }
    // Optionally append a small plant at the end
    if(random.nextDouble() < 0.5) {
      Obstacle plant = new Obstacle();
      plant.smallPlant = true;
      plant.collides = random.nextDouble() < 0.2;
      plant.x = x;
      plant.y = Ground.GROUND_Y - 12 + 5;
      obList.add(plant);
    }
  }
  
  public void enableCheat() {
    // Speed up obstacles and ignore collisions
    cheat = true;
    movementSpeed = 30;
  }
  
  public void disableCheat() {
    // Restore normal speed and collisions
    cheat = false;
    movementSpeed = 8;
  }
  
}
