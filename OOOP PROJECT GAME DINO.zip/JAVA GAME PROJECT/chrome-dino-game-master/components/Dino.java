package components;

import java.awt.Graphics; // rendering API
import java.awt.Rectangle; // collision rectangle
import java.awt.image.BufferedImage; // sprite frames
import java.util.ArrayList; // reserved

import components.Ground; // ground Y reference
import utility.Resource; // image loader

public class Dino {
  // Position bounds and runtime coordinates
  private static int dinoBaseY, dinoTopY, dinoStartX, dinoEndX;
  private static int dinoTop, dinoBottom, topPoint;
  // Render size after scaling
  private static int dinoWidth, dinoHeight;
  private static double scale = 1.5;

  // Jump control flags
  private static boolean topPointReached;
  private static int jumpFactor = 20;

  // State machine values
  public static final int STAND_STILL = 1,
                    RUNNING = 2,
                    JUMPING = 3,
                    DIE = 4;
  private final int LEFT_FOOT = 1,
                    RIGHT_FOOT = 2,
                    NO_FOOT = 3;
  
  private static int state;

  private int foot;

  // Sprite frames
  static BufferedImage image;
  BufferedImage leftFootDino;
  BufferedImage rightFootDino;
  BufferedImage deadDino;

  public Dino() {
    // Load images and compute scaled size and base positions
    image = new Resource().getResourceImage("../images/Dino-stand.png");
    leftFootDino = new Resource().getResourceImage("../images/Dino-left-up.png");
    rightFootDino = new Resource().getResourceImage("../images/Dino-right-up.png");
    deadDino = new Resource().getResourceImage("../images/Dino-big-eyes.png");

    dinoWidth = (int)(image.getWidth() * scale);
    dinoHeight = (int)(image.getHeight() * scale);
    dinoBaseY = Ground.GROUND_Y + 5;
    dinoTopY = Ground.GROUND_Y - dinoHeight + 5;
    dinoStartX = 100;
    dinoEndX = dinoStartX + dinoWidth;
    topPoint = dinoTopY - 120;

    state = 1;
    foot = NO_FOOT;
  }

  // Draw dino depending on state, including jump motion
  public void create(Graphics g) {
    dinoBottom = dinoTop + dinoHeight;

    switch(state) {

      case STAND_STILL:
        System.out.println("stand");
        g.drawImage(image, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null);
        break;

      case RUNNING:
        // Alternate foot frames for a simple animation
        if(foot == NO_FOOT) {
          foot = LEFT_FOOT;
          g.drawImage(leftFootDino, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null);
        } else if(foot == LEFT_FOOT) {
          foot = RIGHT_FOOT;
          g.drawImage(rightFootDino, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null);
        } else {
          foot = LEFT_FOOT;
          g.drawImage(leftFootDino, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null);
        }
        break;

      case JUMPING:
        // Move up until topPoint, then move down to base
        if(dinoTop > topPoint && !topPointReached) {
          g.drawImage(image, dinoStartX, dinoTop -= jumpFactor, dinoWidth, dinoHeight, null);
          break;
        } 
        if(dinoTop >= topPoint && !topPointReached) {
          topPointReached = true;
          g.drawImage(image, dinoStartX, dinoTop += jumpFactor, dinoWidth, dinoHeight, null);
          break;
        }         
        if(dinoTop > topPoint && topPointReached) {      
          if(dinoTopY == dinoTop && topPointReached) {
            state = RUNNING;
            topPointReached = false;
            break;
          }    
          g.drawImage(image, dinoStartX, dinoTop += jumpFactor, dinoWidth, dinoHeight, null);          
          break;
        }
      case DIE: 
        g.drawImage(deadDino, dinoStartX, dinoTop, dinoWidth, dinoHeight, null);    
        break;     
    }
  }

  public void die() {
    // Set death state to change frame and stop motion
    state = DIE;
  }

  public static Rectangle getDino() {
    // Current collision rectangle; adjusts for jump direction
    Rectangle dino = new Rectangle();
    dino.x = dinoStartX;

    if(state == JUMPING && !topPointReached) dino.y = dinoTop - jumpFactor;
    else if(state == JUMPING && topPointReached) dino.y = dinoTop + jumpFactor;
    else if(state != JUMPING) dino.y = dinoTop;

    dino.width = dinoWidth;
    dino.height = dinoHeight;

    return dino;
  }

  public void startRunning() {
    // Initialize running at base Y
    dinoTop = dinoTopY;
    state = RUNNING;
  }

  public void jump() {
    // Begin a jump cycle from base
    dinoTop = dinoTopY;
    topPointReached = false;
    state = JUMPING;
  }

  private class DinoImages {

  }

}
