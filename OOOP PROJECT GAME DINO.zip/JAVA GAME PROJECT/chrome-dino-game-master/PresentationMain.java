import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.*;
import javax.imageio.ImageIO;

public class PresentationMain {
  JFrame mainWindow = new JFrame("T-Rex Run");
  public static String CURRENT_USER;
  public static int WIDTH = 800;
  public static int HEIGHT = 500;
  
  public void createAndShowGUI() {
    mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Container container = mainWindow.getContentPane();
    GamePanel gamePanel = new GamePanel();
    gamePanel.addKeyListener(gamePanel);
    gamePanel.setFocusable(true);
    container.setLayout(new BorderLayout());
    container.add(gamePanel, BorderLayout.CENTER);
    mainWindow.setSize(WIDTH, HEIGHT);
    mainWindow.setResizable(false);
    mainWindow.setVisible(true);
  }
  
  public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        CURRENT_USER = PresentationAuth.AuthDialog.show(null);
        if(CURRENT_USER == null) return;
        new PresentationMain().createAndShowGUI();
      }
    });
  }
  
  static class Resource {
    public BufferedImage getResourceImage(String path) {
      try {
        return ImageIO.read(getClass().getResource(path));
      } catch(Exception e) { return null; }
    }
  }
  
  static class Ground {
    private class GroundImage { BufferedImage image; int x; }
    public static int GROUND_Y;
    private BufferedImage image;
    private ArrayList<GroundImage> groundImageSet;
    public Ground(int panelHeight) {
      GROUND_Y = (int)(panelHeight - 0.25 * panelHeight);
      image = new Resource().getResourceImage("../images/Ground.png");
      groundImageSet = new ArrayList<GroundImage>();
      for(int i=0;i<3;i++){ GroundImage obj=new GroundImage(); obj.image=image; obj.x=0; groundImageSet.add(obj); }
    }
    public void update() {
      Iterator<GroundImage> looper = groundImageSet.iterator();
      GroundImage first = looper.next();
      first.x -= 10;
      int previousX = first.x;
      while(looper.hasNext()){ GroundImage next=looper.next(); next.x=previousX+image.getWidth(); previousX=next.x; }
      if(first.x < -image.getWidth()){ groundImageSet.remove(first); first.x=previousX+image.getWidth(); groundImageSet.add(first); }
    }
    public void create(Graphics g) {
      for(GroundImage img: groundImageSet){ g.drawImage(img.image, (int)img.x, GROUND_Y, null); }
    }
  }
  
  static class Dino {
    private static int dinoBaseY, dinoTopY, dinoStartX, dinoEndX;
    private static int dinoTop, dinoBottom, topPoint;
    private static int dinoWidth, dinoHeight;
    private static double scale = 1.5;
    private static boolean topPointReached;
    private static int jumpFactor = 20;
    public static final int STAND_STILL = 1, RUNNING = 2, JUMPING = 3, DIE = 4;
    private final int LEFT_FOOT = 1, RIGHT_FOOT = 2, NO_FOOT = 3;
    private static int state;
    private int foot;
    static BufferedImage image;
    BufferedImage leftFootDino;
    BufferedImage rightFootDino;
    BufferedImage deadDino;
    public Dino() {
      image = new Resource().getResourceImage("../images/Dino-stand.png");
      leftFootDino = new Resource().getResourceImage("../images/Dino-left-up.png");
      rightFootDino = new Resource().getResourceImage("../images/Dino-right-up.png");
      deadDino = new Resource().getResourceImage("../images/Dino-big-eyes.png");
      dinoWidth = (int)(image.getWidth() * scale);
      dinoHeight = (int)(image.getHeight() * scale);
      dinoBaseY = Ground.GROUND_Y + 5;
      dinoTopY = Ground.GROUND_Y - dinoHeight + 5;
      dinoStartX = 100;
      dinoEndX = dinoStartX + dinoWidth;
      topPoint = dinoTopY - 120;
      state = 1;
      foot = NO_FOOT;
    }
    public void create(Graphics g) {
      dinoBottom = dinoTop + dinoHeight;
      switch(state) {
        case STAND_STILL:
          g.drawImage(image, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null); break;
        case RUNNING:
          if(foot == NO_FOOT){ foot=LEFT_FOOT; g.drawImage(leftFootDino, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null); }
          else if(foot == LEFT_FOOT){ foot=RIGHT_FOOT; g.drawImage(rightFootDino, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null); }
          else { foot=LEFT_FOOT; g.drawImage(leftFootDino, dinoStartX, dinoTopY, dinoWidth, dinoHeight, null); }
          break;
        case JUMPING:
          if(dinoTop > topPoint && !topPointReached){ g.drawImage(image, dinoStartX, dinoTop -= jumpFactor, dinoWidth, dinoHeight, null); break; }
          if(dinoTop >= topPoint && !topPointReached){ topPointReached=true; g.drawImage(image, dinoStartX, dinoTop += jumpFactor, dinoWidth, dinoHeight, null); break; }
          if(dinoTop > topPoint && topPointReached){
            if(dinoTopY == dinoTop && topPointReached){ state=RUNNING; topPointReached=false; break; }
            g.drawImage(image, dinoStartX, dinoTop += jumpFactor, dinoWidth, dinoHeight, null); break;
          }
        case DIE:
          g.drawImage(deadDino, dinoStartX, dinoTop, dinoWidth, dinoHeight, null); break;
      }
    }
    public void die(){ state = DIE; }
    public static Rectangle getDino() {
      Rectangle dino = new Rectangle();
      dino.x = dinoStartX;
      if(state == JUMPING && !topPointReached) dino.y = dinoTop - jumpFactor;
      else if(state == JUMPING && topPointReached) dino.y = dinoTop + jumpFactor;
      else if(state != JUMPING) dino.y = dinoTop;
      dino.width = dinoWidth; dino.height = dinoHeight; return dino;
    }
    public void startRunning(){ dinoTop = dinoTopY; state = RUNNING; }
    public void jump(){ dinoTop = dinoTopY; topPointReached = false; state = JUMPING; }
  }
  
  static class Obstacles {
    private class Obstacle {
      BufferedImage image; int x; int y; boolean smallPlant; boolean collides;
      Rectangle getObstacle() {
        Rectangle obstacle = new Rectangle(); obstacle.x=x; obstacle.y=y;
        if(smallPlant){ obstacle.width=16; obstacle.height=12; }
        else { obstacle.width=image.getWidth(); obstacle.height=image.getHeight(); }
        return obstacle;
      }
    }
    private int firstX; private int obstacleInterval; private int movementSpeed; private boolean cheat; private Random random;
    private ArrayList<BufferedImage> imageList; private ArrayList<Obstacle> obList;
    public Obstacles(int firstPos) {
      obList = new ArrayList<Obstacle>(); imageList = new ArrayList<BufferedImage>(); random = new Random();
      firstX = firstPos; obstacleInterval = 300; movementSpeed = 8;
      imageList.add(new Resource().getResourceImage("../images/Cactus-1.png"));
      imageList.add(new Resource().getResourceImage("../images/Cactus-2.png"));
      imageList.add(new Resource().getResourceImage("../images/Cactus-2.png"));
      imageList.add(new Resource().getResourceImage("../images/Cactus-1.png"));
      imageList.add(new Resource().getResourceImage("../images/Cactus-5.png"));
      int x = firstX;
      for(BufferedImage bi : imageList) {
        Obstacle ob = new Obstacle(); ob.image=bi; ob.x=x; ob.y=Ground.GROUND_Y - bi.getHeight() + 5; ob.smallPlant=false; ob.collides=true; x += obstacleInterval; obList.add(ob);
      }
      Obstacle plant = new Obstacle(); plant.smallPlant=true; plant.collides=random.nextDouble() < 0.2; plant.x=x; plant.y=Ground.GROUND_Y - 12 + 5; obList.add(plant);
    }
    public void update() {
      Iterator<Obstacle> looper = obList.iterator();
      Obstacle firstOb = looper.next(); firstOb.x -= movementSpeed;
      while(looper.hasNext()){ Obstacle ob = looper.next(); ob.x -= movementSpeed; }
      if(firstOb.image != null && firstOb.x < -firstOb.image.getWidth()) {
        obList.remove(firstOb);
        firstOb.x = obList.get(obList.size()-1).x + obstacleInterval;
        if(random.nextDouble() < 0.3){ firstOb.smallPlant=true; firstOb.image=null; firstOb.y=Ground.GROUND_Y - 12 + 5; firstOb.collides=random.nextDouble() < 0.2; }
        else { BufferedImage bi = imageList.get(random.nextInt(imageList.size())); firstOb.smallPlant=false; firstOb.image=bi; firstOb.y=Ground.GROUND_Y - bi.getHeight() + 5; firstOb.collides=true; }
        obList.add(firstOb);
      }
    }
    public void create(Graphics g) {
      for(Obstacle ob : obList) {
        if(ob.smallPlant){ g.setColor(new Color(34,139,34)); g.fillRect(ob.x, ob.y, 16, 12); }
        else { g.drawImage(ob.image, ob.x, ob.y, null); }
      }
    }
    public boolean hasCollided() {
      if(cheat) return false;
      for(Obstacle ob : obList) {
        if(Dino.getDino().intersects(ob.getObstacle())) {
          if(!ob.smallPlant || ob.collides) return true;
        }
      }
      return false;
    }
    public void resume() {
      int x = firstX/2; obList = new ArrayList<Obstacle>();
      for(BufferedImage bi : imageList) {
        Obstacle ob = new Obstacle(); ob.image=bi; ob.x=x; ob.y=Ground.GROUND_Y - bi.getHeight() + 5; ob.smallPlant=false; ob.collides=true; x += obstacleInterval; obList.add(ob);
      }
      if(random.nextDouble() < 0.5) { Obstacle plant = new Obstacle(); plant.smallPlant=true; plant.collides=random.nextDouble() < 0.2; plant.x=x; plant.y=Ground.GROUND_Y - 12 + 5; obList.add(plant); }
    }
    public void enableCheat(){ cheat=true; movementSpeed=30; }
    public void disableCheat(){ cheat=false; movementSpeed=8; }
  }
  
  static class GamePanel extends JPanel implements KeyListener, Runnable {
    public static int WIDTH; public static int HEIGHT; private Thread animator;
    private boolean running=false; private boolean gameOver=false; private StringBuilder inputBuffer = new StringBuilder();
    Ground ground; Dino dino; Obstacles obstacles; private int score;
    public GamePanel() {
      WIDTH = PresentationMain.WIDTH; HEIGHT = PresentationMain.HEIGHT;
      ground = new Ground(HEIGHT); dino = new Dino(); obstacles = new Obstacles((int)(WIDTH * 1.5)); score = 0;
      setSize(WIDTH, HEIGHT); setVisible(true);
    }
    public void paint(Graphics g) {
      super.paint(g);
      g.setColor(new Color(135,206,235)); g.fillRect(0,0,getWidth(),getHeight());
      g.setColor(new Color(214,182,127)); g.fillRect(0, Ground.GROUND_Y, getWidth(), getHeight() - Ground.GROUND_Y);
      g.setFont(new Font("Courier New", Font.BOLD, 25)); g.drawString(Integer.toString(score), getWidth()/2 - 5, 100);
      ground.create(g); dino.create(g); obstacles.create(g);
    }
    public void run() {
      running = true;
      while(running) {
        updateGame(); repaint();
        try { Thread.sleep(50); } catch(InterruptedException e){}
      }
    }
    public void updateGame() {
      score += 1; ground.update(); obstacles.update();
      if(obstacles.hasCollided()) {
        dino.die(); repaint(); running=false; gameOver=true;
        new PresentationAuth.UserStore().updateBest(PresentationMain.CURRENT_USER, score);
      }
    }
    public void reset() {
      score = 0; obstacles.resume(); gameOver=false;
    }
    public void keyTyped(KeyEvent e) {
      char c = e.getKeyChar();
      if(c == ' ') {
        if(gameOver) reset();
        if (animator == null || !running) { animator = new Thread(this); animator.start(); dino.startRunning(); } else { dino.jump(); }
      } else {
        inputBuffer.append(Character.toLowerCase(c));
        if(inputBuffer.length() > 8) inputBuffer.delete(0, inputBuffer.length() - 8);
        if(inputBuffer.toString().endsWith("hack")) obstacles.enableCheat();
        if(inputBuffer.toString().endsWith("off")) obstacles.disableCheat();
      }
    }
    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
  }
}
