import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
// Simplified: no hashing; plaintext for presentation only
import java.util.LinkedHashMap;
import java.util.Map;

class PresentationAuth {
  public static class AuthDialog extends JDialog {
    private JTextField userField = new JTextField();
    private JPasswordField passField = new JPasswordField();
    private String selectedUser;
    public AuthDialog(JFrame parent) {
      super(parent, "Login / Sign up", true);
      JPanel form = new JPanel(new GridLayout(2,2,8,8));
      form.add(new JLabel("Username"));
      form.add(userField);
      form.add(new JLabel("Password"));
      form.add(passField);
      JButton login = new JButton("Login");
      JButton signup = new JButton("Sign up");
      JPanel actions = new JPanel();
      actions.add(login);
      actions.add(signup);
      setLayout(new BorderLayout(8,8));
      add(form, BorderLayout.CENTER);
      add(actions, BorderLayout.SOUTH);
      setSize(300,150);
      setLocationRelativeTo(parent);
      UserStore store = new UserStore();
      login.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          String u = userField.getText().trim();
          String p = new String(passField.getPassword());
        String ul = u.toLowerCase();
        if(!ul.endsWith("@gmail.com")) {
          JOptionPane.showMessageDialog(AuthDialog.this, "Please use a Gmail address (must end with @gmail.com)");
          return;
        }
          if(store.verify(u,p)){
            selectedUser = u;
            dispose();
          }
        }
      });
      signup.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          String u = userField.getText().trim();
          String p = new String(passField.getPassword());
        String ul = u.toLowerCase();
        if(!ul.endsWith("@gmail.com")) {
          JOptionPane.showMessageDialog(AuthDialog.this, "Please use a Gmail address (must end with @gmail.com)");
          return;
        }
          if(store.create(u,p)){
            selectedUser = u;
            dispose();
          }
        }
      });
    }
    public static String show(JFrame parent){
      AuthDialog d = new AuthDialog(parent);
      d.setVisible(true);
      return d.selectedUser;
    }
  }
  public static class UserStore {
    private final File file = new File("users.db");
    private Map<String, Record> data = new LinkedHashMap<>();
    private static class Record {
      String hash;
      int best;
    }
    // Simplified: file-based storage only; no hashing
    public boolean create(String u, String p) {
      load();
      if(data.containsKey(u)) return false;
      Record r = new Record();
      r.hash = p;
      r.best = 0;
      data.put(u, r);
      persist();
      return true;
    }
    public boolean verify(String u, String p) {
      load();
      Record r = data.get(u);
      if(r == null) return false;
      return r.hash.equals(p);
    }
    public void updateBest(String u, int score) {
      load();
      Record r = data.get(u);
      if(r == null) return;
      if(score > r.best) {
        r.best = score;
        persist();
      }
    }
    private void load() {
      data.clear();
      if(!file.exists()) return;
      try(BufferedReader br = new BufferedReader(new FileReader(file))) {
        String line;
        while((line = br.readLine()) != null) {
          String[] p = line.split(":", 3);
          if(p.length >= 2) {
            Record r = new Record();
            r.hash = p[1];
            r.best = p.length == 3 ? Integer.parseInt(p[2]) : 0;
            data.put(p[0], r);
          }
        }
      } catch(Exception e) {}
    }
    private void persist() {
      try(BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
        for(Map.Entry<String, Record> e : data.entrySet()) {
          bw.write(e.getKey()+":"+e.getValue().hash+":"+e.getValue().best);
          bw.newLine();
        }
      } catch(Exception e) {}
    }
  }
}
